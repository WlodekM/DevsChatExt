

function validateForm() {
    document.getElementById("pid").innerHTML = document.forms["myForm"]["ffile"].value;
//file.name == "photo.png"
//file.type == "image/png"
//file.size == 300821
}
function opts() {
    if (chrome.runtime.openOptionsPage) {
      chrome.runtime.openOptionsPage();
    } else {
      window.open(chrome.runtime.getURL('options.html'));
    }
  }